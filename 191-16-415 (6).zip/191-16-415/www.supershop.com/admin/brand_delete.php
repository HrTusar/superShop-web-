<?php
define("HOST_NAME", "localhost");
define("USER_NAME", "root");
define("PASSWORD", "");
define("DATABASE", "misrdb_001");
$db_connect = mysqli_connect(HOST_NAME, USER_NAME, PASSWORD, DATABASE);

  $subcategory_id = $_GET["subcategory_id"];
  $category_id = $_GET["category_id"];
  $product_name = $_GET["product_name"];
  $product_order = $_GET["product_order"];
//   $delete_brand_query = "DELETE FROM `brand` WHERE `id` = '".$id."'";
//   $delete_brand = mysqli_query($db_connect, $delete_brand_query);
//   if($delete_brand){
//     header("location: brand.php");
//   }else{
//     echo "error in query";
//   }
$delete_brand_query = "DELETE FROM `products` WHERE `subcategory_id` = '".$subcategory_id."' AND `category_id` = '".$category_id."' AND `product_name` = '".$product_name."' AND `product_order` = '".$product_order."'";
  $delete_brand = mysqli_query($db_connect, $delete_brand_query);
  if($delete_brand){
    header("location: list-products.php");
  }else{
    echo "error in query";
  }
?>