<?php
class AdminController extends Controller
{
	public function tryLogin($username, $password)
	{
		$sql_code = "SELECT * FROM `admins` WHERE `admin_username`=:ADMIN_USERNAME AND `admin_password`=:ADMIN_PASSWORD";
		$query = $this->connection->prepare($sql_code);
		
		$values = array(
			":ADMIN_USERNAME" => $username,
			":ADMIN_PASSWORD" => $password
		);
		$query->execute($values);
		
		$dataList = $query->fetchAll(PDO::FETCH_ASSOC);
		$totalRowSelected = $query->rowCount();
		
		if($totalRowSelected > 0)
			return $dataList;
		else
			return 0;
	}
}