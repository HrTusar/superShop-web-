<?php
class DashboardController extends Controller
{
	
}