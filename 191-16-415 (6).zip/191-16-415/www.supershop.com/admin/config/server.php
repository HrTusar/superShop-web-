<?php 
# SET TIME ZONE
date_default_timezone_set("Asia/Dhaka");

# SET SMTP CONFIGURATION
$GLOBALS['SMTPHOST'] = "mail.xoomserver.com";
$GLOBALS['SMTPUSER'] = "nirjhor@xoomserver.com";
$GLOBALS['SMTPPORT'] = "465";
$GLOBALS['SMTPAUTH'] = "ssl"; # ssl / tls / none
$GLOBALS['SMTPPASS'] = "abc123";
