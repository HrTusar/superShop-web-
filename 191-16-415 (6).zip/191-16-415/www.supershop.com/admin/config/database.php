<?php 
# DATABASE 1 CONFIGURATION
	$GLOBALS['DBHOST'] = "localhost";
	$GLOBALS['DBNAME'] = "misrdb_001";
	$GLOBALS['DBUSER'] = "root";
	$GLOBALS['DBPASS'] = "";
?>